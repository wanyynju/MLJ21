clear
clc

rng(1)

%Load Data
load('./syn_data');
[T,n] = size(B);
cum_losses = zeros(T,3);

%Generate Delays
c = 10;
ds = c.*[2,3,2,1,4,1,3];
d = zeros(T,1);
for i = 1:T
    index = mod(i,7);
    if index == 0
        index = 7;
    end
    d(i) = ds(index);
end

D = sum(d);
DBGD;
cum_losses(1:T,1)=cumsum(mean(loss,2));

DBOGD_SC;
cum_losses(1:T,2)=cumsum(mean(loss,2));

DBOGD_SC_2_points;
cum_losses(1:T,3)=cumsum(result./10);

% Create figure
figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1);
hold(axes1,'on');

% Create multiple lines using matrix input to semilogy
semilogy1 = semilogy(cum_losses,'LineWidth',3,'Parent',axes1);
set(semilogy1(1),'DisplayName','DBGD','LineStyle','-.',...
    'Color',[0.749019622802734 0.749019622802734 0]);
set(semilogy1(2),'DisplayName','DOGD-SC$_{n+1}$',...
    'Color',[0.749019622802734 0 0.749019622802734]);
set(semilogy1(3),'DisplayName','DOGD-SC$_2$','LineStyle','--',...
    'Color',[0 0.749019622802734 0.749019622802734]);

% Create xlabel
xlabel('Number of Rounds','Interpreter','latex');

% Create ylabel
ylabel('Cumulative Loss','Interpreter','latex');

ylim(axes1,[0.1 250]);
box(axes1,'on');
% Set the remaining axes properties
set(axes1,'FontSize',16,'YMinorTick','on','YScale','log');
% Create legend
legend1 = legend(axes1,'show');
set(legend1,'Location','southeast','Interpreter','latex');




