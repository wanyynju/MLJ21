
%Strong Convexity
lambda = 2;

%DOGD-SC with (n+1) points
delta = log(T)/T;
R_2 = 1 - delta;
x = ones(n,1);
x = (R_2.*x)./norm(x,2);
G = zeros(n,T);

loss = zeros(T,n+1);
I = eye(n);
h = 0;
for i = 1:T
    b = B(i,:)';
    
    loss(i,1) = x'*x + b'*x;
    for j = 2:n+1
        loss(i,j) = (x+delta.*I(:,j-1))'*(x+delta.*I(:,j-1))+b'*(x+delta.*I(:,j-1));
        G(:,i) = G(:,i) + ((loss(i,j)-loss(i,1))/delta).*I(:,j-1);
    end
    
    count = 0;
    g = zeros(n,1);
    for j = max(i-4*c,1):i
        if j+d(j)-1 == i
            count = count + 1;
            g = g + G(:,j);
        end
    end
    
    h = h + count*lambda;
    
    if count > 0
        x = x - (1/h).*g;
        if norm(x,2) > R_2
            x = (R_2.*x)./norm(x,2);
        end
    end
    
end
