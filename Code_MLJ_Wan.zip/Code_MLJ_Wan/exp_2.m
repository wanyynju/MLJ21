clear
clc

%Load Data
load('./syn_data');
[T,n] = size(B);
cum_losses = zeros(T,3);

%Generate Delays
c = 10;
ds = c.*[2,3,2,1,4,1,3];
d = zeros(T,1);
for i = 1:T
    index = mod(i,7);
    if index == 0
        index = 7;
    end
    d(i) = ds(index);
end

OGD_SC;
cum_losses(1:T,1)=cumsum(loss);

D = sum(d);
DOGD_C;
cum_losses(1:T,2)=cumsum(loss);

DOGD_SC;
cum_losses(1:T,3)=cumsum(loss);

figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1);
hold(axes1,'on');

% Create multiple lines using matrix input to semilogy
semilogy1 = semilogy(cum_losses,'LineWidth',3,'Parent',axes1);
set(semilogy1(1),'DisplayName','OGD-SC','LineStyle','--');
set(semilogy1(2),'DisplayName','DOGD','LineStyle','-.',...
    'Color',[0.929411768913269 0.694117665290833 0.125490203499794]);
set(semilogy1(3),'DisplayName','DOGD-SC','Color',[1 0 0]);

% Create xlabel
xlabel('Number of Rounds','Interpreter','latex');

% Create ylabel
ylabel('Cumulative Loss','Interpreter','latex');

ylim(axes1,[0.1 250]);
box(axes1,'on');
% Set the remaining axes properties
set(axes1,'FontSize',16,'YMinorTick','on','YScale','log');
% Create legend
legend1 = legend(axes1,'show');
set(legend1,'Location','southeast','Interpreter','latex');

