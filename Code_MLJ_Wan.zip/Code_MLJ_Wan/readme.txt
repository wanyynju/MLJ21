
# Description
The package includes the codes and datasets used in the paper "Yuanyu Wan, Wei-Wei Tu, Lijun Zhang. Online Strongly Convex Optimization with Unknown Delays.", which is submitted to the ACML2021 special issue of Machine Learning.

#Dataset
syn_data.mat -> The synthetic data utilized to define loss functions.

# How to run?
1.Run exp_1.m for the result shown in Figure 1(a).
2.Run exp_2.m for the result shown in Figure 1(b).
3.Run exp_3.m for the result shown in Figure 2(a).
4.Run exp_4.m for the result shown in Figure 2(b).

# Other Specific Functions
gen_data.m -> The function utilized to generate the synthetic data.
DOGD_SC.m -> Algorithm 1 proposed in our paper.
DBOGD_SC.m -> Algorithm 2 proposed in our paper.
DBOGD_SC_2_points.m -> Algorithm 3 proposed in our paper.
OGD_SC.m -> Online gradient descent for strongly convex functions proposed in "Elad Hazan, Amit Agarwal, Satyen Kale. Logarithmic regret algorithms for online convex optimization. Machine Learning 69(2):169-192, 2007."
DOGD_C.m -> Delayed online gradient descent proposed in "Kent Quanrud and Daniel Khashabi. Online learning with adversarial delays. In NIPS, pages 1270-1278, 2015."
DBGD.m -> Delayed bandit gradient descent proposed in "Bingcong Li, Tianyi Chen, and Georgios B. Giannakis. Bandit online learning with unknown delays. In AISTATS, pages 993-1002, 2019."




