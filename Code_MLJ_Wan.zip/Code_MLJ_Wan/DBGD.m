
L = 2+sqrt(n);
eta = 1/(L*sqrt(T+D));

%DBGD
delta = 1/(T+D);
R_2 = 1-delta;
x = ones(n,1);
x = (R_2.*x)./norm(x,2);
G = zeros(n,T);

loss = zeros(T,n+1);
I = eye(n);

for i = 1:T
    b = B(i,:)';
    
    loss(i,1) = x'*x + b'*x;
    for j = 2:n+1
        loss(i,j) = (x+delta.*I(:,j-1))'*(x+delta.*I(:,j-1))+b'*(x+delta.*I(:,j-1));
        G(:,i) = G(:,i) + ((loss(i,j)-loss(i,1))/delta).*I(:,j-1);
    end
    
    count = 0;
    for j = max(i-4*c,1):i
        if j+d(j)-1 == i
            count = count + 1;
            x = x - eta.*G(:,j);
            if norm(x,2) > R_2
                x = (R_2.*x)./norm(x,2);
            end
        end
    end
    
end