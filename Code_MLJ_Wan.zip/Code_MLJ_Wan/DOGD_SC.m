
%Strong Convexity
lambda = 2;

%DOGD-SC
x = ones(n,1)./sqrt(n);
G = zeros(n,T);

loss = zeros(T,1);
h = 0;
for i = 1:T
    b = B(i,:)';
    
    loss(i) = x'*x + b'*x;
    G(:,i) = 2.*x + b;
    
    count = 0;
    g = zeros(n,1);
    for j = max(i-4*c,1):i
        if j+d(j)-1 == i
            count = count + 1;
            g = g + G(:,j);
        end
    end
    
    h = h + count*lambda;
    
    if count > 0
        x = x - (1/h).*g;
        if norm(x,2) > 1
            x = x./norm(x,2);
        end
    end
    
end

