
%Strong Convexity
lambda = 2;

%OGD-SC
x = ones(n,1)./sqrt(n);

loss = zeros(T,1);
h = 0;
for i = 1:T
    b = B(i,:)';
    
    loss(i) = x'*x + b'*x;
    g = 2.*x + b;
    
    h = h + lambda;
    x = x - (1/h).*g;
    if norm(x,2) > 1
        x = x./norm(x,2);
    end
    
end
