

%Lipschitz Constant
L=2+sqrt(n);

% Learning Rate
eta=1/(L*sqrt(T+D));

%DOGD
x = ones(n,1)./sqrt(n);
G = zeros(n,T);

loss = zeros(T,1);

for i = 1:T
    b = B(i,:)';
    
    loss(i) = x'*x + b'*x;
    G(:,i) = 2.*x + b;
    
    count = 0;
    g = zeros(n,1);
    for j = max(i-4*c,1):i
        if j+d(j)-1 == i
            count = count + 1;
            g = g + G(:,j);
        end
    end
    
    if count > 0
        x = x - eta.*g;
        if norm(x,2) > 1
            x = x./norm(x,2);
        end
    end
    
end
