
%Strong Convexity
lambda = 2;

result = zeros(T,1);

for repeat = 1:10

    %DOGD-SC with 2 points
    delta = log(T)/T;
    R_2 = 1-delta;
    x = ones(n,1);
    x = (R_2.*x)./norm(x,2);
    G = zeros(n,T);

    loss = zeros(T,2);

    h = 0;
    for i = 1:T
        b = B(i,:)';
    
        u = randn(n,1);
        u = u./norm(u);
    
        loss(i,1) = (x+delta.*u)'*(x+delta.*u) + b'*(x+delta.*u);
        loss(i,2) = (x-delta.*u)'*(x-delta.*u) + b'*(x-delta.*u);
    
        G(:,i) = G(:,i) + (n/2)*((loss(i,1)-loss(i,2))/delta).*u;
    
        count = 0;
        g = zeros(n,1);
        for j = max(i-4*c,1):i
            if j+d(j)-1 == i
                count = count + 1;
                g = g + G(:,j);
            end
        end
    
        h = h + count*lambda;
    
        if count > 0
            x = x - (1/h).*g;
            if norm(x,2) > R_2
                x = (R_2.*x)./norm(x,2);
            end
        end
    
    end
    result = result + mean(loss,2);
end
